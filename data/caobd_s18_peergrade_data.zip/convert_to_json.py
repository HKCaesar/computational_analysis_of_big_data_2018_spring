# Hacky script to convert mongo bson dumps to JSON serializable string format

import json
import dateutil.parser as dp
import os

def parse(d):
    try:
        return 0.001 * d
    except TypeError:
        return int(dp.parse(d).strftime("%s"))

for f in os.listdir("."):
    if "bson" in f:
        with open(f) as fp:
            tmp = eval(fp.read().replace("true", "True").replace("false", "False").replace("ObjectId", "").replace("new Date", "parse"))
        with open(f.replace(".bson", ""), 'w') as fp:
            json.dump(tmp, fp)